<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<c:set var="pageTitle" value="Danh Sách Sản Phẩm" scope="request" />
<jsp:include page="../common/header.jsp" />

<main class="main-wrapper">

    <!-- Thông báo kết quả thao tác (Alert Messages) -->
    <c:if test="${param.message == 'created'}">
        <div class="alert alert-success">
            <div><i class="fa-solid fa-circle-check"></i> <strong>Thành công!</strong> Đã thêm sản phẩm mới vào hệ thống.</div>
            <button class="alert-close" onclick="this.parentElement.remove();">&times;</button>
        </div>
    </c:if>
    <c:if test="${param.message == 'updated'}">
        <div class="alert alert-success">
            <div><i class="fa-solid fa-circle-check"></i> <strong>Thành công!</strong> Đã cập nhật thông tin sản phẩm.</div>
            <button class="alert-close" onclick="this.parentElement.remove();">&times;</button>
        </div>
    </c:if>
    <c:if test="${param.message == 'deleted'}">
        <div class="alert alert-success">
            <div><i class="fa-solid fa-circle-check"></i> <strong>Thành công!</strong> Đã xóa sản phẩm khỏi cơ sở dữ liệu.</div>
            <button class="alert-close" onclick="this.parentElement.remove();">&times;</button>
        </div>
    </c:if>
    <c:if test="${param.message == 'delete_failed'}">
        <div class="alert alert-danger">
            <div><i class="fa-solid fa-triangle-exclamation"></i> <strong>Lỗi!</strong> Không thể xóa sản phẩm do ràng buộc dữ liệu.</div>
            <button class="alert-close" onclick="this.parentElement.remove();">&times;</button>
        </div>
    </c:if>
    <c:if test="${param.message == 'notfound'}">
        <div class="alert alert-danger">
            <div><i class="fa-solid fa-circle-xmark"></i> <strong>Lỗi!</strong> Không tìm thấy sản phẩm yêu cầu trong hệ thống.</div>
            <button class="alert-close" onclick="this.parentElement.remove();">&times;</button>
        </div>
    </c:if>

    <!-- Thống kê Dashboard KPI Cards -->
    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-info">
                <h4>Tổng số mặt hàng</h4>
                <div class="stat-number">${totalProducts}</div>
            </div>
            <div class="stat-icon blue">
                <i class="fa-solid fa-cube"></i>
            </div>
        </div>

        <div class="stat-card">
            <div class="stat-info">
                <h4>Tổng tồn kho</h4>
                <div class="stat-number">${totalStock} <span style="font-size: 0.9rem; font-weight: 500; color: #64748b;">chiếc</span></div>
            </div>
            <div class="stat-icon green">
                <i class="fa-solid fa-warehouse"></i>
            </div>
        </div>

        <div class="stat-card">
            <div class="stat-info">
                <h4>Tổng giá trị kho</h4>
                <div class="stat-number">
                    <fmt:formatNumber value="${totalValue}" type="currency" currencySymbol="$" maxFractionDigits="2" />
                </div>
            </div>
            <div class="stat-icon purple">
                <i class="fa-solid fa-sack-dollar"></i>
            </div>
        </div>
    </div>

    <!-- Thanh công cụ & Tìm kiếm -->
    <div class="action-bar">
        <form action="${pageContext.request.contextPath}/products" method="GET" class="search-form">
            <input type="hidden" name="action" value="search">
            <span class="search-icon"><i class="fa-solid fa-magnifying-glass"></i></span>
            <input type="text" name="keyword" class="search-input" id="liveSearchInput"
                   placeholder="Tìm kiếm theo tên sản phẩm..." value="${searchKeyword}">
            <button type="submit" class="btn-search">Tìm kiếm</button>
            <c:if test="${not empty searchKeyword}">
                <a href="${pageContext.request.contextPath}/products" style="margin-left: 0.5rem; color: #64748b; text-decoration: none;" title="Xóa bộ lọc">
                    <i class="fa-solid fa-circle-xmark"></i>
                </a>
            </c:if>
        </form>

        <a href="${pageContext.request.contextPath}/products?action=create" class="btn btn-primary">
            <i class="fa-solid fa-plus"></i> Thêm Sản Phẩm Mới
        </a>
    </div>

    <!-- Bảng danh sách sản phẩm -->
    <div class="table-card">
        <div class="table-responsive">
            <table class="custom-table">
                <thead>
                    <tr>
                        <th style="width: 80px;">ID</th>
                        <th>Tên Sản Phẩm</th>
                        <th style="width: 160px;">Giá Bán</th>
                        <th style="width: 140px;">Số Lượng</th>
                        <th style="width: 140px;">Trạng Thái</th>
                        <th style="width: 180px; text-align: center;">Thao Tác</th>
                    </tr>
                </thead>
                <tbody id="productTableBody">
                    <c:choose>
                        <c:when test="${not empty products}">
                            <c:forEach var="product" items="${products}">
                                <tr>
                                    <td>
                                        <span class="id-badge">#${product.id}</span>
                                    </td>
                                    <td>
                                        <div class="product-name">
                                            <i class="fa-solid fa-box" style="color: #6366f1;"></i>
                                            <span><c:out value="${product.name}" /></span>
                                        </div>
                                    </td>
                                    <td>
                                        <span class="price-text">
                                            <fmt:formatNumber value="${product.price}" type="currency" currencySymbol="$" maxFractionDigits="2" />
                                        </span>
                                    </td>
                                    <td>
                                        <strong>${product.quantity}</strong> chiếc
                                    </td>
                                    <td>
                                        <c:choose>
                                            <c:when test="${product.quantity > 10}">
                                                <span class="badge badge-success"><i class="fa-solid fa-circle-check"></i> Còn hàng</span>
                                            </c:when>
                                            <c:when test="${product.quantity > 0}">
                                                <span class="badge badge-warning"><i class="fa-solid fa-clock"></i> Sắp hết</span>
                                            </c:when>
                                            <c:otherwise>
                                                <span class="badge badge-danger"><i class="fa-solid fa-ban"></i> Hết hàng</span>
                                            </c:otherwise>
                                        </c:choose>
                                    </td>
                                    <td>
                                        <div class="actions-cell" style="justify-content: center;">
                                            <a href="${pageContext.request.contextPath}/products?action=edit&id=${product.id}"
                                               class="btn btn-sm btn-action-edit" title="Sửa sản phẩm">
                                                <i class="fa-solid fa-pen-to-square"></i> Sửa
                                            </a>
                                            <button type="button" class="btn btn-sm btn-action-delete"
                                                    onclick="openDeleteModal(${product.id}, '<c:out value="${product.name}"/>')"
                                                    title="Xóa sản phẩm">
                                                <i class="fa-solid fa-trash-can"></i> Xóa
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            </c:forEach>
                        </c:when>
                        <c:otherwise>
                            <tr>
                                <td colspan="6">
                                    <div class="empty-state">
                                        <div class="empty-state-icon"><i class="fa-solid fa-box-open"></i></div>
                                        <h3 style="font-size: 1.1rem; font-weight: 600; color: #1e293b; margin-bottom: 0.25rem;">Chưa có sản phẩm nào</h3>
                                        <p style="font-size: 0.875rem;">Không tìm thấy sản phẩm nào phù hợp với dữ liệu tìm kiếm.</p>
                                    </div>
                                </td>
                            </tr>
                        </c:otherwise>
                    </c:choose>
                </tbody>
            </table>
        </div>
    </div>

</main>

<!-- Modal xác nhận xóa sản phẩm -->
<div class="modal-overlay" id="deleteModal">
    <div class="modal-content">
        <div class="modal-icon">
            <i class="fa-solid fa-triangle-exclamation"></i>
        </div>
        <h3 class="modal-title">Xác nhận xóa sản phẩm?</h3>
        <p class="modal-desc">
            Bạn có chắc chắn muốn xóa sản phẩm <strong id="deleteProductName" style="color: #0f172a;"></strong> khỏi hệ thống? Hành động này không thể hoàn tác!
        </p>
        <div class="modal-actions">
            <button type="button" class="btn btn-secondary" onclick="closeDeleteModal()">
                Hủy bỏ
            </button>
            <a href="#" id="confirmDeleteBtn" class="btn btn-danger">
                <i class="fa-solid fa-trash-can"></i> Xác nhận Xóa
            </a>
        </div>
    </div>
</div>

<jsp:include page="../common/footer.jsp" />
