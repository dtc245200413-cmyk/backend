package com.codegym.controller;

import com.codegym.dao.IProductDAO;
import com.codegym.dao.ProductDAO;
import com.codegym.model.Product;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 * Controller chính điều phối các luồng nghiệp vụ của Product (MVC Controller).
 * Mapped tới URL: /products
 */
@WebServlet(name = "ProductServlet", urlPatterns = {"/products"})
public class ProductServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private IProductDAO productDAO;

    @Override
    public void init() {
        productDAO = new ProductDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html; charset=UTF-8");

        String action = request.getParameter("action");
        if (action == null) {
            action = "";
        }

        try {
            switch (action) {
                case "new":
                case "create":
                    showCreateForm(request, response);
                    break;
                case "edit":
                    showEditForm(request, response);
                    break;
                case "delete":
                    deleteProduct(request, response);
                    break;
                case "search":
                    searchProducts(request, response);
                    break;
                default:
                    listProducts(request, response);
                    break;
            }
        } catch (Exception ex) {
            throw new ServletException(ex);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html; charset=UTF-8");

        String action = request.getParameter("action");
        if (action == null) {
            action = "";
        }

        try {
            switch (action) {
                case "create":
                case "insert":
                    createProduct(request, response);
                    break;
                case "edit":
                case "update":
                    updateProduct(request, response);
                    break;
                default:
                    listProducts(request, response);
                    break;
            }
        } catch (Exception ex) {
            throw new ServletException(ex);
        }
    }

    // 1. Hiển thị danh sách sản phẩm
    private void listProducts(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<Product> products = productDAO.selectAllProducts();
        
        // Thống kê nhanh để hiển thị KPI thẻ trên Dashboard
        int totalProducts = products.size();
        int totalStock = 0;
        double totalValue = 0.0;
        for (Product p : products) {
            totalStock += p.getQuantity();
            totalValue += (p.getPrice() * p.getQuantity());
        }

        request.setAttribute("products", products);
        request.setAttribute("totalProducts", totalProducts);
        request.setAttribute("totalStock", totalStock);
        request.setAttribute("totalValue", totalValue);

        RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/views/product/list.jsp");
        dispatcher.forward(request, response);
    }

    // 2. Tìm kiếm sản phẩm theo tên
    private void searchProducts(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String keyword = request.getParameter("keyword");
        if (keyword == null) {
            keyword = "";
        }
        keyword = keyword.trim();

        List<Product> products = productDAO.searchByName(keyword);

        int totalProducts = products.size();
        int totalStock = 0;
        double totalValue = 0.0;
        for (Product p : products) {
            totalStock += p.getQuantity();
            totalValue += (p.getPrice() * p.getQuantity());
        }

        request.setAttribute("products", products);
        request.setAttribute("searchKeyword", keyword);
        request.setAttribute("totalProducts", totalProducts);
        request.setAttribute("totalStock", totalStock);
        request.setAttribute("totalValue", totalValue);

        RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/views/product/list.jsp");
        dispatcher.forward(request, response);
    }

    // 3. Hiển thị form tạo mới sản phẩm
    private void showCreateForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/views/product/create.jsp");
        dispatcher.forward(request, response);
    }

    // 4. Xử lý tạo mới sản phẩm từ form POST
    private void createProduct(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String name = request.getParameter("name");
        String priceStr = request.getParameter("price");
        String quantityStr = request.getParameter("quantity");

        String errorMessage = null;

        if (name == null || name.trim().isEmpty()) {
            errorMessage = "Tên sản phẩm không được để trống!";
        }

        double price = 0.0;
        int quantity = 0;

        try {
            if (errorMessage == null) {
                price = Double.parseDouble(priceStr);
                if (price < 0) {
                    errorMessage = "Giá sản phẩm phải lớn hơn hoặc bằng 0!";
                }
            }
        } catch (NumberFormatException e) {
            errorMessage = "Định dạng giá sản phẩm không hợp lệ!";
        }

        try {
            if (errorMessage == null) {
                quantity = Integer.parseInt(quantityStr);
                if (quantity < 0) {
                    errorMessage = "Số lượng sản phẩm phải lớn hơn hoặc bằng 0!";
                }
            }
        } catch (NumberFormatException e) {
            errorMessage = "Định dạng số lượng sản phẩm không hợp lệ!";
        }

        if (errorMessage != null) {
            request.setAttribute("errorMessage", errorMessage);
            request.setAttribute("product", new Product(name, price, quantity));
            RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/views/product/create.jsp");
            dispatcher.forward(request, response);
            return;
        }

        Product newProduct = new Product(name.trim(), price, quantity);
        boolean success = productDAO.insertProduct(newProduct);

        if (success) {
            response.sendRedirect(request.getContextPath() + "/products?message=created");
        } else {
            request.setAttribute("errorMessage", "Không thể thêm sản phẩm vào cơ sở dữ liệu!");
            RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/views/product/create.jsp");
            dispatcher.forward(request, response);
        }
    }

    // 5. Hiển thị form sửa sản phẩm
    private void showEditForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        Product existingProduct = productDAO.selectProduct(id);

        if (existingProduct == null) {
            response.sendRedirect(request.getContextPath() + "/products?message=notfound");
            return;
        }

        request.setAttribute("product", existingProduct);
        RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/views/product/edit.jsp");
        dispatcher.forward(request, response);
    }

    // 6. Xử lý cập nhật sản phẩm từ form POST
    private void updateProduct(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        String name = request.getParameter("name");
        String priceStr = request.getParameter("price");
        String quantityStr = request.getParameter("quantity");

        String errorMessage = null;

        if (name == null || name.trim().isEmpty()) {
            errorMessage = "Tên sản phẩm không được để trống!";
        }

        double price = 0.0;
        int quantity = 0;

        try {
            if (errorMessage == null) {
                price = Double.parseDouble(priceStr);
                if (price < 0) {
                    errorMessage = "Giá sản phẩm phải lớn hơn hoặc bằng 0!";
                }
            }
        } catch (NumberFormatException e) {
            errorMessage = "Định dạng giá sản phẩm không hợp lệ!";
        }

        try {
            if (errorMessage == null) {
                quantity = Integer.parseInt(quantityStr);
                if (quantity < 0) {
                    errorMessage = "Số lượng sản phẩm phải lớn hơn hoặc bằng 0!";
                }
            }
        } catch (NumberFormatException e) {
            errorMessage = "Định dạng số lượng sản phẩm không hợp lệ!";
        }

        if (errorMessage != null) {
            request.setAttribute("errorMessage", errorMessage);
            request.setAttribute("product", new Product(id, name, price, quantity));
            RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/views/product/edit.jsp");
            dispatcher.forward(request, response);
            return;
        }

        Product product = new Product(id, name.trim(), price, quantity);
        boolean success = productDAO.updateProduct(product);

        if (success) {
            response.sendRedirect(request.getContextPath() + "/products?message=updated");
        } else {
            request.setAttribute("errorMessage", "Không thể cập nhật sản phẩm trong cơ sở dữ liệu!");
            request.setAttribute("product", product);
            RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/views/product/edit.jsp");
            dispatcher.forward(request, response);
        }
    }

    // 7. Xóa sản phẩm theo ID
    private void deleteProduct(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        boolean success = productDAO.deleteProduct(id);

        if (success) {
            response.sendRedirect(request.getContextPath() + "/products?message=deleted");
        } else {
            response.sendRedirect(request.getContextPath() + "/products?message=delete_failed");
        }
    }
}
