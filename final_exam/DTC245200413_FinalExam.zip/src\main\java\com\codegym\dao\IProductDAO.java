package com.codegym.dao;

import com.codegym.model.Product;
import java.util.List;

/**
 * Giao diện Data Access Object (DAO) định nghĩa các thao tác CRUD đối với bảng products.
 */
public interface IProductDAO {

    /**
     * Lấy toàn bộ danh sách sản phẩm từ cơ sở dữ liệu.
     * @return Danh sách Product
     */
    List<Product> selectAllProducts();

    /**
     * Tìm kiếm một sản phẩm theo ID.
     * @param id Mã sản phẩm
     * @return Đối tượng Product tìm được, hoặc null nếu không tồn tại
     */
    Product selectProduct(int id);

    /**
     * Thêm mới một sản phẩm vào cơ sở dữ liệu.
     * @param product Đối tượng sản phẩm cần thêm
     * @return true nếu thêm thành công, false nếu thất bại
     */
    boolean insertProduct(Product product);

    /**
     * Cập nhật thông tin của một sản phẩm hiện có.
     * @param product Đối tượng sản phẩm với dữ liệu mới
     * @return true nếu cập nhật thành công, false nếu thất bại
     */
    boolean updateProduct(Product product);

    /**
     * Xóa một sản phẩm khỏi cơ sở dữ liệu theo ID.
     * @param id Mã sản phẩm cần xóa
     * @return true nếu xóa thành công, false nếu thất bại
     */
    boolean deleteProduct(int id);

    /**
     * Tìm kiếm các sản phẩm theo tên (hỗ trợ tìm kiếm tương đối LIKE).
     * @param keyword Từ khóa tìm kiếm
     * @return Danh sách các sản phẩm khớp với từ khóa
     */
    List<Product> searchByName(String keyword);
}
