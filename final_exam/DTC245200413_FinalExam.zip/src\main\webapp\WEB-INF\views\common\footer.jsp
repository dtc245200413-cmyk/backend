<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!-- Footer -->
<footer class="footer">
    <div style="max-width: 1200px; margin: 0 auto; display: flex; flex-wrap: wrap; justify-content: space-between; align-items: center; gap: 0.5rem;">
        <div>
            &copy; 2026 <strong>Product Management System</strong>. CodeGym Final Exam Module 3.
        </div>
        <div>
            Học viên: <strong>DTC245200413</strong> | Kiến trúc: <strong>MVC + DAO + JDBC</strong>
        </div>
    </div>
</footer>

<!-- Script file -->
<script src="${pageContext.request.contextPath}/js/script.js"></script>
</body>
</html>
