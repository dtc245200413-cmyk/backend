<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%
    // Tự động chuyển hướng trang chủ vào Servlet điều khiển sản phẩm
    response.sendRedirect(request.getContextPath() + "/products");
%>
