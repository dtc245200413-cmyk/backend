package com.codegym.utils;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

/**
 * Tiện ích kết nối cơ sở dữ liệu MySQL qua JDBC (Singleton / Helper Pattern).
 */
public class DatabaseConnection {

    private static String jdbcURL = "jdbc:mysql://localhost:3306/product_management?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC&characterEncoding=UTF-8";
    private static String jdbcUsername = "root";
    private static String jdbcPassword = "";
    private static String jdbcDriver = "com.mysql.cj.jdbc.Driver";

    static {
        // Tải cấu hình từ database.properties nếu có
        try (InputStream input = DatabaseConnection.class.getClassLoader().getResourceAsStream("database.properties")) {
            if (input != null) {
                Properties prop = new Properties();
                prop.load(input);
                jdbcDriver = prop.getProperty("db.driver", jdbcDriver);
                jdbcURL = prop.getProperty("db.url", jdbcURL);
                jdbcUsername = prop.getProperty("db.username", jdbcUsername);
                jdbcPassword = prop.getProperty("db.password", jdbcPassword);
            }
        } catch (Exception e) {
            System.err.println("Không thể nạp database.properties, sử dụng cấu hình mặc định: " + e.getMessage());
        }

        // Đăng ký JDBC Driver
        try {
            Class.forName(jdbcDriver);
        } catch (ClassNotFoundException e) {
            System.err.println("Không tìm thấy MySQL JDBC Driver: " + e.getMessage());
        }
    }

    /**
     * Mở kết nối mới đến CSDL MySQL.
     *
     * @return Đối tượng Connection
     * @throws SQLException Nếu xảy ra lỗi kết nối
     */
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
    }

    /**
     * Đóng an toàn các tài nguyên JDBC để tránh rò rỉ bộ nhớ (Connection leak).
     */
    public static void close(Connection conn, Statement stmt, ResultSet rs) {
        if (rs != null) {
            try {
                rs.close();
            } catch (SQLException ignored) {
            }
        }
        if (stmt != null) {
            try {
                stmt.close();
            } catch (SQLException ignored) {
            }
        }
        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException ignored) {
            }
        }
    }
}
