<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${pageTitle != null ? pageTitle : "Hệ Thống Quản Lý Sản Phẩm"} | CodeGym Final Exam</title>
    <!-- Google Fonts: Inter -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <!-- Custom Stylesheet -->
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body>

<!-- Navbar -->
<header class="navbar">
    <div class="nav-container">
        <a href="${pageContext.request.contextPath}/products" class="brand-logo">
            <div class="brand-icon">
                <i class="fa-solid fa-boxes-stacked"></i>
            </div>
            <span>PRODUCT MANAGEMENT</span>
        </a>
        <div style="display: flex; align-items: center; gap: 1rem;">
            <a href="${pageContext.request.contextPath}/products" style="color: #ffffff; text-decoration: none; font-size: 0.9rem; font-weight: 500;">
                <i class="fa-solid fa-table-list"></i> Danh Sách
            </a>
            <a href="${pageContext.request.contextPath}/products?action=create" style="color: #67e8f9; text-decoration: none; font-size: 0.9rem; font-weight: 600;">
                <i class="fa-solid fa-plus-circle"></i> Thêm Mới
            </a>
            <span class="nav-badge">
                <i class="fa-solid fa-graduation-cap"></i> JSP &amp; Servlet Module
            </span>
        </div>
    </div>
</header>
