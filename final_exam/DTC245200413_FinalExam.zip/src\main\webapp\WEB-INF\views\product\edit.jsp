<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>

<c:set var="pageTitle" value="Chỉnh Sửa Sản Phẩm" scope="request" />
<jsp:include page="../common/header.jsp" />

<main class="main-wrapper">

    <div class="form-card">
        <div class="form-header" style="background: linear-gradient(135deg, #2563eb 0%, #1e40af 100%);">
            <h2><i class="fa-solid fa-pen-to-square"></i> Cập Nhật Thông Tin Sản Phẩm</h2>
            <p>Chỉnh sửa thông tin cho sản phẩm mã <strong>#${product.id}</strong></p>
        </div>

        <div class="form-body">
            <!-- Thông báo lỗi nếu có -->
            <c:if test="${not empty errorMessage}">
                <div class="alert alert-danger" style="margin-bottom: 1.25rem;">
                    <div><i class="fa-solid fa-circle-exclamation"></i> ${errorMessage}</div>
                </div>
            </c:if>

            <form action="${pageContext.request.contextPath}/products" method="POST">
                <input type="hidden" name="action" value="update">
                <input type="hidden" name="id" value="${product.id}">

                <!-- Mã ID sản phẩm (Chỉ xem) -->
                <div class="form-group">
                    <label class="form-label">Mã sản phẩm (ID)</label>
                    <input type="text" class="form-control" value="#${product.id}" disabled
                           style="background-color: #f1f5f9; color: #64748b; font-weight: 600;">
                </div>

                <!-- Tên sản phẩm -->
                <div class="form-group">
                    <label for="name" class="form-label">
                        Tên sản phẩm <span class="required">*</span>
                    </label>
                    <input type="text" id="name" name="name" class="form-control"
                           placeholder="Ví dụ: MacBook Pro 16 M3 Max" required
                           value="<c:out value='${product.name}'/>">
                </div>

                <!-- Giá bán -->
                <div class="form-group">
                    <label for="price" class="form-label">
                        Giá bán ($) <span class="required">*</span>
                    </label>
                    <input type="number" id="price" name="price" class="form-control"
                           step="0.01" min="0" placeholder="Ví dụ: 1999.99" required
                           value="${product.price}">
                </div>

                <!-- Số lượng -->
                <div class="form-group">
                    <label for="quantity" class="form-label">
                        Số lượng tồn kho <span class="required">*</span>
                    </label>
                    <input type="number" id="quantity" name="quantity" class="form-control"
                           min="0" placeholder="Ví dụ: 25" required
                           value="${product.quantity}">
                </div>

                <!-- Nút điều hướng -->
                <div class="form-actions">
                    <a href="${pageContext.request.contextPath}/products" class="btn btn-secondary">
                        <i class="fa-solid fa-arrow-left"></i> Hủy bỏ
                    </a>
                    <button type="submit" class="btn btn-primary" style="background-color: #2563eb;">
                        <i class="fa-solid fa-check"></i> Cập Nhật Thay Đổi
                    </button>
                </div>
            </form>
        </div>
    </div>

</main>

<jsp:include page="../common/footer.jsp" />
