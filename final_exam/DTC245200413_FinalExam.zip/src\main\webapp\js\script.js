/**
 * Script tương tác giao diện người dùng cho Hệ thống Quản lý Sản phẩm
 */

// Hàm mở Modal xác nhận xóa sản phẩm
function openDeleteModal(productId, productName) {
    const modal = document.getElementById('deleteModal');
    const deleteProductNameElem = document.getElementById('deleteProductName');
    const confirmDeleteBtn = document.getElementById('confirmDeleteBtn');

    if (modal && deleteProductNameElem && confirmDeleteBtn) {
        deleteProductNameElem.textContent = productName;
        confirmDeleteBtn.href = window.location.pathname + '?action=delete&id=' + productId;
        modal.classList.add('active');
    }
}

// Hàm đóng Modal xác nhận xóa
function closeDeleteModal() {
    const modal = document.getElementById('deleteModal');
    if (modal) {
        modal.classList.remove('active');
    }
}

// Đóng modal khi bấm ra ngoài vùng nội dung modal
document.addEventListener('click', function (e) {
    const modal = document.getElementById('deleteModal');
    if (modal && e.target === modal) {
        closeDeleteModal();
    }
});

// Đóng modal khi nhấn phím Escape
document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') {
        closeDeleteModal();
    }
});

// Tự động ẩn các thông báo Alert sau 4 giây
document.addEventListener('DOMContentLoaded', function () {
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(function (alert) {
        setTimeout(function () {
            alert.style.transition = 'opacity 0.4s ease, transform 0.4s ease';
            alert.style.opacity = '0';
            alert.style.transform = 'translateY(-10px)';
            setTimeout(function () {
                alert.remove();
            }, 400);
        }, 4000);
    });

    // Lọc tìm kiếm trực tiếp trên bảng sản phẩm (Live Search)
    const liveSearchInput = document.getElementById('liveSearchInput');
    if (liveSearchInput) {
        liveSearchInput.addEventListener('input', function (e) {
            const query = e.target.value.toLowerCase().trim();
            const tableRows = document.querySelectorAll('#productTableBody tr');

            tableRows.forEach(function (row) {
                const text = row.textContent.toLowerCase();
                if (text.includes(query)) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        });
    }
});
