# 📦 BÀI KIỂM TRA CUỐI MODULE 3: PHÁT TRIỂN ỨNG DỤNG WEB VỚI JSP & SERVLET
## Đề tài: Hệ Thống Quản Lý Sản Phẩm (Product Management System)

> **Học viên thực hiện:** DTC245200413 (`dtc245200413-cmyk`)  
> **Kiến trúc ứng dụng:** MVC (Model - View - Controller) + DAO Pattern + JDBC  
> **Hệ quản trị CSDL:** MySQL 8.0+  
> **Web Server:** Apache Tomcat 8.5 / 9.0 / 10.0+  
> **Repository GitHub:** [https://github.com/dtc245200413-cmyk/jsp-servlet-product-management](https://github.com/dtc245200413-cmyk/jsp-servlet-product-management)  
> **File nộp bài chuẩn quy định:** `DTC245200413_FinalExam.zip`

---

## 📋 MỤC LỤC
1. [Giới thiệu & Mục tiêu](#1-giới-thiệu--mục-tiêu)
2. [Sơ đồ kiến trúc ứng dụng (MVC Architecture)](#2-sơ-đồ-kiến-trúc-ứng-dụng-mvc-architecture)
3. [Cấu trúc cơ sở dữ liệu (Database Schema)](#3-cấu-trúc-cơ-sở-dữ-liệu-database-schema)
4. [Các chức năng chính của ứng dụng](#4-các-chức-năng-chính-của-ứng-dụng)
   - [4.1. Hiển thị danh sách sản phẩm & Thống kê KPI](#41-hiển-thị-danh-sách-sản-phẩm--thống-kê-kpi)
   - [4.2. Thêm mới sản phẩm (Create Product)](#42-thêm-mới-sản-phẩm-create-product)
   - [4.3. Chỉnh sửa thông tin sản phẩm (Edit Product)](#43-chỉnh-sửa-thông-tin-sản-phẩm-edit-product)
   - [4.4. Xóa sản phẩm với Modal xác nhận an toàn (Delete Product)](#44-xóa-sản-phẩm-với-modal-xác-nhận-an-toàn-delete-product)
   - [4.5. Tìm kiếm sản phẩm theo tên (Search Product)](#45-tìm-kiếm-sản-phẩm-theo-tên-search-product)
5. [Cấu trúc thư mục dự án](#5-cấu-trúc-thư-mục-dự-án)
6. [Hướng dẫn cài đặt & Triển khai trên Apache Tomcat](#6-hướng-dẫn-cài-đặt--triển-khai-trên-apache-tomcat)

---

## 1. GIỚI THIỆU & MỤC TIÊU

Ứng dụng được xây dựng nhằm hiện thực hóa trọn vẹn quy trình phát triển Web ứng dụng công nghệ Java EE:
* **Tầng Controller:** Java Servlet (`ProductServlet.java`) tiếp nhận và phân phối HTTP Request (`doGet`, `doPost`), điều phối dữ liệu và điều hướng trang (`forward`, `sendRedirect`).
* **Tầng Data Access (DAO):** Áp dụng DAO Design Pattern (`IProductDAO`, `ProductDAO`), kết nối CSDL MySQL qua JDBC `PreparedStatement` chống tấn công SQL Injection.
* **Tầng Model:** Lớp thực thể `Product.java` mô hình hóa bảng dữ liệu sản phẩm.
* **Tầng View:** Các trang JSP kết hợp thư viện thẻ chuẩn JSTL (`c:forEach`, `c:if`, `c:choose`, `fmt:formatNumber`) hiển thị giao diện chuyên nghiệp, responsive.

---

## 2. SƠ ĐỒ KIẾN TRÚC ỨNG DỤNG (MVC ARCHITECTURE)

![Kiến trúc MVC JSP Servlet](assets/mvc_architecture.svg)

---

## 3. CẤU TRÚC CƠ SỞ DỮ LIỆU (DATABASE SCHEMA)

* **Tên Database:** `product_management`
* **Tên Bảng:** `products`

```sql
CREATE DATABASE IF NOT EXISTS product_management CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE product_management;

CREATE TABLE products (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    price DOUBLE NOT NULL CHECK (price >= 0),
    quantity INT NOT NULL CHECK (quantity >= 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
```

---

## 4. CÁC CHỨC NĂNG CHÍNH CỦA ỨNG DỤNG

### 4.1. Hiển thị danh sách sản phẩm & Thống kê KPI
* Hiển thị bảng dữ liệu sản phẩm trực quan: **ID**, **Tên sản phẩm**, **Giá bán** (định dạng tiền tệ chuẩn `$`), **Số lượng**, **Trạng thái tồn kho** (Huy hiệu: *Còn hàng*, *Sắp hết*, *Hết hàng*).
* Bổ sung 3 thẻ KPI Dashboard thống kê tự động: Tổng số mặt hàng, Tổng lượng hàng trong kho, Tổng giá trị tồn kho.

### 4.2. Thêm mới sản phẩm (Create Product)
* Cung cấp biểu mẫu trực quan tại URL `/products?action=create`.
* Kiểm tra tính hợp lệ dữ liệu (Validation cả phía Client và Server): tên không để trống, giá bán $\ge 0$, số lượng $\ge 0$.
* Thêm thành công tự động chuyển về trang danh sách kèm thông báo Alert xanh lá mượt mà.

### 4.3. Chỉnh sửa thông tin sản phẩm (Edit Product)
* Chọn nút "Sửa" tại bất kỳ dòng sản phẩm nào (`/products?action=edit&id=X`).
* Form tự động điền sẵn dữ liệu hiện tại của sản phẩm để người dùng cập nhật.
* Sau khi bấm "Cập Nhật Thay Đổi", dữ liệu được lưu tức thì vào MySQL.

### 4.4. Xóa sản phẩm với Modal xác nhận an toàn (Delete Product)
* Khi bấm nút "Xóa", hệ thống **KHÔNG xóa ngay** mà bật **Modal Popup xác nhận** (`#deleteModal`).
* Modal hiển thị rõ ràng tên sản phẩm cần xóa và cảnh báo hành động không thể hoàn tác, tránh việc bấm nhầm mất dữ liệu.

### 4.5. Tìm kiếm sản phẩm theo tên (Search Product)
* Hỗ trợ tìm kiếm Backend thông qua câu lệnh SQL `LIKE %keyword%`.
* Tích hợp tính năng **Live Search tức thì** bằng JavaScript trên giao diện giúp tìm nhanh sản phẩm trong bảng mà không cần tải lại trang.

---

## 5. CẤU TRÚC THƯ MỤC DỰ ÁN

```text
jsp-servlet-product-management/
├── pom.xml                                  # Cấu hình dự án Maven & Dependencies
├── database.sql                             # Script SQL tạo CSDL và chèn dữ liệu mẫu
├── README.md                                # Tài liệu hướng dẫn đồ án
├── DTC245200413_FinalExam.zip               # File nén nộp bài kiểm tra cuối module
├── assets/
│   └── mvc_architecture.svg                 # Sơ đồ kiến trúc luồng dữ liệu MVC
└── src/
    └── main/
        ├── java/
        │   └── com/
        │       └── codegym/
        │           ├── controller/
        │           │   └── ProductServlet.java      # Servlet điều hướng nghiệp vụ MVC
        │           ├── dao/
        │           │   ├── IProductDAO.java         # Interface tầng DAO
        │           │   └── ProductDAO.java          # Triển khai JDBC CRUD với MySQL
        │           ├── model/
        │           │   └── Product.java             # Lớp thực thể sản phẩm
        │           └── utils/
        │               └── DatabaseConnection.java  # Quản lý kết nối JDBC MySQL
        ├── resources/
        │   └── database.properties                  # File cấu hình chuỗi kết nối DB
        └── webapp/
            ├── index.jsp                            # Trang chủ (Redirect sang /products)
            ├── css/
            │   └── style.css                        # CSS hiện đại, responsive, animations
            ├── js/
            │   └── script.js                        # JS điều khiển Modal xóa & Live Search
            └── WEB-INF/
                ├── web.xml                          # File cấu hình triển khai Servlet
                └── views/
                    ├── common/
                    │   ├── header.jsp               # Phần đầu trang dùng chung
                    │   └── footer.jsp               # Phần chân trang dùng chung
                    └── product/
                        ├── list.jsp                 # Giao diện danh sách sản phẩm & KPI
                        ├── create.jsp               # Giao diện form thêm mới sản phẩm
                        └── edit.jsp                 # Giao diện form chỉnh sửa sản phẩm
```

---

## 6. HƯỚNG DẪN CÀI ĐẶT & TRIỂN KHAI TRÊN APACHE TOMCAT

### Bước 1: Khởi tạo Cơ sở dữ liệu MySQL
1. Mở MySQL Workbench hoặc chạy lệnh từ Command Line:
```bash
mysql -u root -p < database.sql
```
2. Kiểm tra tài khoản kết nối trong file `src/main/resources/database.properties`:
```properties
db.url=jdbc:mysql://localhost:3306/product_management?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC&characterEncoding=UTF-8
db.username=root
db.password=
```

### Bước 2: Mở và chạy dự án bằng IntelliJ IDEA / Eclipse
1. Chọn **File** $\rightarrow$ **Open...** $\rightarrow$ Chọn thư mục dự án `jsp-servlet-product-management`.
2. Đợi Maven tự động tải các dependencies (`servlet-api`, `jsp-api`, `jstl`, `mysql-connector-j`).
3. Cấu hình Run/Debug Configuration:
   * Chọn **Add Configuration...** $\rightarrow$ Chọn **Tomcat Server** (Local).
   * Tại tab **Deployment**, bấm dấu **+** $\rightarrow$ Chọn **Artifact**: `product-management:war exploded`.
   * Đặt Application Context là: `/` hoặc `/product-management`.
4. Bấm **Run** hoặc **Debug** (phím `Shift + F10`).
5. Truy cập trình duyệt tại địa chỉ:
   ```text
   http://localhost:8080/products
   ```
