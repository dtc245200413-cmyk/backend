package com.codegym.model;

import java.io.Serializable;

/**
 * Lớp Model đại diện cho thực thể Sản phẩm (Product) trong cơ sở dữ liệu.
 */
public class Product implements Serializable {
    private static final long serialVersionUID = 1L;

    private int id;
    private String name;
    private double price;
    private int quantity;

    // Constructor mặc định (no-args)
    public Product() {
    }

    // Constructor khi thêm mới (không kèm id vì id tự tăng)
    public Product(String name, double price, int quantity) {
        this.name = name;
        this.price = price;
        this.quantity = quantity;
    }

    // Constructor đầy đủ tham số
    public Product(int id, String name, double price, int quantity) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.quantity = quantity;
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    // Helper kiểm tra tình trạng tồn kho
    public String getStockStatus() {
        if (this.quantity <= 0) {
            return "Hết hàng";
        } else if (this.quantity < 10) {
            return "Sắp hết";
        } else {
            return "Còn hàng";
        }
    }

    // Helper tính tổng giá trị hàng tồn
    public double getTotalValue() {
        return this.price * this.quantity;
    }

    @Override
    public String toString() {
        return "Product{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", price=" + price +
                ", quantity=" + quantity +
                '}';
    }
}
